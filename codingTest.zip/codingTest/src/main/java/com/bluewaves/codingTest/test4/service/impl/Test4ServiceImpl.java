package com.bluewaves.codingTest.test4.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bluewaves.codingTest.test4.mapper.Test4Mapper;
import com.bluewaves.codingTest.test4.service.Test4Service;
import com.bluewaves.codingTest.test4.vo.Board4VO;
import com.bluewaves.codingTest.test4.vo.Paging4Dto;
import com.bluewaves.codingTest.test4.vo.Test4VO;

/**
 * <pre>
 * @FileName : Test4ServiceImpl.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트4 서비스 구현
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
@Service
public class Test4ServiceImpl implements Test4Service {

	@Autowired
	private Test4Mapper test4Mapper;
	
	/**
	 * <pre>
	 * @Date : 2019. 4. 22.
	 * @author dnms5
	 * @History : 
	 * @Description : 게시글 목록 조회
	 * </pre>
	 *
	 * @return
	 */
	public List<Test4VO> getList() {
		return test4Mapper.getList();
	}

	public List<Board4VO> boardList(Paging4Dto paging4Dto) {
		// TODO Auto-generated method stub
		return test4Mapper.boardList(paging4Dto);
	}
	
	public int countList() {
		// TODO Auto-generated method stub
		return test4Mapper.countList();
	}

	public Board4VO getContent(Board4VO board4Vo) {
		// TODO Auto-generated method stub
		return test4Mapper.getContent(board4Vo);
	}

	public void insertContent(Board4VO board4Vo) {
		// TODO Auto-generated method stub
		test4Mapper.insertContent(board4Vo);
	}

	public void updateContent(Board4VO board4Vo) {
		// TODO Auto-generated method stub
		test4Mapper.updateContent(board4Vo);
	}

	public void deleteContent(Board4VO board4Vo) {
		// TODO Auto-generated method stub
		test4Mapper.deleteContent(board4Vo);
	}

	


	
}

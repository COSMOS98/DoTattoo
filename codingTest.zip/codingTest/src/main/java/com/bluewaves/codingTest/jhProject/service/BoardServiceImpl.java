package com.bluewaves.codingTest.jhProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bluewaves.codingTest.jhProject.mapper.BoardMapper;
import com.bluewaves.codingTest.jhProject.vo.BoardVo;
import com.bluewaves.codingTest.jhProject.vo.PagingDto;
import com.bluewaves.codingTest.jhProject.vo.UserVo;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardMapper boardMapper;

	@Override
	public List<BoardVo> getBoardList(PagingDto pagingDto) {

		return boardMapper.getBoardList(pagingDto);
		
	}

	@Override
	public void insertContent(BoardVo boardVo) {
		boardMapper.insertContent(boardVo);
		
	}

	@Override
	public BoardVo getContentByBno(String bNo) {
		return boardMapper.getContentByBno(bNo);
	}

	

	@Override
	public void updateContent(BoardVo boardVo) {
		boardMapper.updateContent(boardVo);
		
	}
	

	@Override
	public void deleteContent(BoardVo boardVo) {
		boardMapper.deleteContent(boardVo);
		
	}

	
	@Override
	public void insertUser(UserVo userVo) {
		boardMapper.insertUser(userVo);
		
	}

	@Override
	public UserVo login(String uId, String uPw) {
		return boardMapper.login(uId, uPw);
	}

	@Override
	public boolean checkDupId(String uId) {
		int count = boardMapper.checkDupId(uId);
		if (count > 0) {
			return true;
		}
		return false;
	}

}

package com.bluewaves.codingTest.jhProject.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bluewaves.codingTest.jhProject.service.BoardServiceImpl;
import com.bluewaves.codingTest.jhProject.vo.BoardVo;
import com.bluewaves.codingTest.jhProject.vo.PagingDto;
import com.bluewaves.codingTest.jhProject.vo.UserVo;

@Controller
@RequestMapping("jh")
public class JhController {
	
	@Autowired
	BoardServiceImpl boardServiceImpl;

	@RequestMapping("/home.do")
	public String jhHome() {
		
		return "jhProject/jhHome";
		
	}
	
	@RequestMapping("/login.do")
	public String Login() {
		return "jhProject/jhLogin";
	}
	
	// 로그인 실행
	@RequestMapping(value="/loginRun.do", method=RequestMethod.POST)
	public String loginRun(String uId, String uPw, HttpSession session, RedirectAttributes rttr, HttpServletRequest req) throws Exception{

		String page = null;
		String msg = null;
		UserVo userVo = boardServiceImpl.login(uId, uPw);
		session = req.getSession();
		 
		 if(userVo != null) {
		  session.setAttribute("userVo", userVo);
		  msg = "true";
		  page = "redirect:/jh/boardList.do";
		 } else {
		  msg = "false";
		  page = "redirect:/jh/login.do";
		 }

		 rttr.addFlashAttribute("msg", msg);
		 return page;
		}
	
	// 로그아웃 실행
	@RequestMapping(value="/logoutRun.do")
	public String logoutRun(HttpSession session) throws Exception{
		session.invalidate();
		return "redirect:/jh/home.do";
	}
	
	
	@RequestMapping("/join.do")
	public String jhJoin() {
		return "jhProject/jhJoin";
	}
	
	@RequestMapping(value = "/checkDupId.do", method = RequestMethod.GET)
	@ResponseBody
	public String checkDupNick(String uId) throws Exception {
		boolean result = boardServiceImpl.checkDupId(uId);
		return String.valueOf(result);
	}
		  
	
	// 사용자 등록 실행
	@RequestMapping(value="/insertUserRun.do", method=RequestMethod.POST)
	public String insertUserRun(UserVo userVo) throws Exception{
		boardServiceImpl.insertUser(userVo);
		return "redirect:/jh/login.do";
	}
	
	// 글 목록
	@RequestMapping(value="/boardList.do", method=RequestMethod.GET)
	public String jhBoardList(Model model, PagingDto pagingDto, HttpSession session) throws Exception{
		// 로그인 확인
		if(session.getAttribute("userVo") != null) {
			UserVo userVo = (UserVo)session.getAttribute("userVo");
			String uName = userVo.getuName();
			model.addAttribute("uName", uName);
		} else {
			  session.setAttribute("userVo", null);
			  return "redirect:/jh/login.do";
		}
			 
		List<BoardVo> list = boardServiceImpl.getBoardList(pagingDto);
		model.addAttribute("list", list);
		model.addAttribute("pagingDto", pagingDto);
		
		return "jhProject/jhBoardList";
	}
	
	// 컨텐츠 상세페이지
	@RequestMapping("/boardContent.do")
	public String jhBoardContent(Model model, String bNo, HttpSession session) {
		// 로그인 확인
		if(session.getAttribute("userVo") != null) {
			UserVo userVo = (UserVo)session.getAttribute("userVo");
			String uName = userVo.getuName();
			model.addAttribute("uName", uName);
		} else {
			  session.setAttribute("userVo", null);
			  return "redirect:/jh/login.do";
		}
		BoardVo boardVo = boardServiceImpl.getContentByBno(bNo);
		model.addAttribute("boardVo", boardVo);
		
		return "jhProject/jhBoardContent";
	}
	
	// 컨텐츠 등록 실행
	@RequestMapping(value="/insertContentRun.do", method=RequestMethod.POST)
	public String insertContentRun(BoardVo boardVo, Model model, HttpSession session) throws Exception{
		// 로그인 확인
		if(session.getAttribute("userVo") != null) {
			UserVo userVo = (UserVo)session.getAttribute("userVo");
			String uName = userVo.getuName();
			model.addAttribute("uName", uName);
		} else {
			  session.setAttribute("userVo", null);
			  return "redirect:/jh/login.do";
		}
		boardServiceImpl.insertContent(boardVo);
		return "redirect:/jh/boardList.do";
	}
	
	// 컨텐츠 수정 실행
	@RequestMapping(value="/updateContentRun.do", method=RequestMethod.POST)
	public String updateContentRun(BoardVo boardVo, HttpSession session, Model model) throws Exception{
		// 로그인 확인
		if(session.getAttribute("userVo") != null) {
			UserVo userVo = (UserVo)session.getAttribute("userVo");
			String uName = userVo.getuName();
			model.addAttribute("uName", uName);
		} else {
			  session.setAttribute("userVo", null);
			  return "redirect:/jh/login.do";
		}
		boardServiceImpl.updateContent(boardVo);
		return "redirect:/jh/boardList.do";
	}
	
	// 컨텐츠 삭제 실행
	@RequestMapping(value="/deleteContentRun.do", method=RequestMethod.POST)
	public String deleteContentRun(BoardVo boardVo, HttpSession session, Model model) throws Exception{
		// 로그인 확인
		if(session.getAttribute("userVo") != null) {
			UserVo userVo = (UserVo)session.getAttribute("userVo");
			String uName = userVo.getuName();
			model.addAttribute("uName", uName);
		} else {
			  session.setAttribute("userVo", null);
			  return "redirect:/jh/login.do";
		}
		boardServiceImpl.deleteContent(boardVo);
		return "redirect:/jh/boardList.do";
	}
}

package com.bluewaves.codingTest.test1.vo;

/**
 * <pre>
 * @FileName : Test1VO.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트1 VO
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
public class Test1VO {	

}

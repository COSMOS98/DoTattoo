package com.bluewaves.codingTest.jhProject.service;

import java.util.List;

import com.bluewaves.codingTest.jhProject.vo.BoardVo;
import com.bluewaves.codingTest.jhProject.vo.PagingDto;
import com.bluewaves.codingTest.jhProject.vo.UserVo;

public interface BoardService {
	
	public List<BoardVo> getBoardList(PagingDto pagingDto);
	public void insertContent(BoardVo boardVo);
	public BoardVo getContentByBno(String bNo);
	public void updateContent(BoardVo boardVo);
	public void deleteContent(BoardVo boardVo);
	
	public void insertUser(UserVo userVo);
	public UserVo login(String uId, String uPw);
	public boolean checkDupId(String uId);

}

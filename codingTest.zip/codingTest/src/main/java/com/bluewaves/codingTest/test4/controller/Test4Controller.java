package com.bluewaves.codingTest.test4.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bluewaves.codingTest.test4.service.Test4Service;
import com.bluewaves.codingTest.test4.vo.Board4VO;
import com.bluewaves.codingTest.test4.vo.Paging4Dto;

/**
 * <pre>
 * @FileName : Test4Controller.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트4 컨트롤러
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
@Controller
public class Test4Controller {

	@Autowired
	private Test4Service test4ServiceImpl;
	
	@RequestMapping(value="/step4/step4List.do", method=RequestMethod.GET)
	public String test3Form(Model model, Paging4Dto paging4Dto) {
		List<Board4VO> list = test4ServiceImpl.boardList(paging4Dto);
		int count = test4ServiceImpl.countList();
		paging4Dto.setCount(count);
		
		System.out.println("###### perPage :: "+paging4Dto.getPerPage());
		System.out.println("###### perPage :: "+paging4Dto.getPerPage());
		
		model.addAttribute("list", list);
		model.addAttribute("paging4Dto", paging4Dto);
		return "test4/test4List";
	}
	
	@RequestMapping("/step4/step4Content.do")
	public String test4Content(Model model, @ModelAttribute("vo") Board4VO vo) {
		
		System.out.println("################### vo ::: "+vo.getbNo());
		System.out.println("################### vo ::: "+vo.getbName());
		System.out.println("################### vo ::: "+vo.getbContent());
		
		Board4VO boardVo = test4ServiceImpl.getContent(vo);
		
		model.addAttribute("boardVo", boardVo);
		
		return "test4/test4Content";
	}
	
//	@RequestMapping("/step4/step4Content.do")
//	public String test4Content(Model model, String bNo) {
//		Board4VO boardVo = test4ServiceImpl.getContent(bNo);
//		model.addAttribute("boardVo", boardVo);
//		return "test4/test4Content";
//	}
	
	@RequestMapping(value="/step4/step4ContentInsertRun.do", method=RequestMethod.POST)
	public String insertContent(Board4VO board4Vo) {
		test4ServiceImpl.insertContent(board4Vo);
		return "redirect:/step4/step4List.do";
	}
	
	@RequestMapping(value="/step4/step4ContentUpdateRun.do", method=RequestMethod.POST)
	public String updateContent(Board4VO board4Vo) {
		test4ServiceImpl.updateContent(board4Vo);
		return "redirect:/step4/step4List.do";
	}
	
	@RequestMapping(value="/step4/step4ContentDeleteRun.do", method=RequestMethod.POST)
	public String deleteContent(Board4VO board4Vo) {
		test4ServiceImpl.deleteContent(board4Vo);
		return "redirect:/step4/step4List.do";
	}
}

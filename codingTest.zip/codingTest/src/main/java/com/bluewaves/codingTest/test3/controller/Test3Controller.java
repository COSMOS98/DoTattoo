package com.bluewaves.codingTest.test3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <pre>
 * @FileName : Test3Controller.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트3 컨트롤러
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
@Controller
public class Test3Controller {

	/**
	 * <pre>
	 * @Date : 2019. 4. 22.
	 * @author dnms5
	 * @History : 
	 * @Description : 코딩테스트3입력 폼
	 * </pre>
	 *
	 * @return
	 */
	@RequestMapping("/step3/step3Form.do")
	public String test3Form() {
		
		return "test3/test3Form";
	}
}

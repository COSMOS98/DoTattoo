package com.bluewaves.codingTest.test1.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * <pre>
 * @FileName : Test1Controller.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트1 컨트롤러
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
@Controller
public class Test1Controller {

	/**
	 * <pre>
	 * @Date : 2019. 4. 22.
	 * @author dnms5
	 * @History : 
	 * @Description : 코딩테스트1 입력 폼
	 * </pre>
	 *
	 * @return
	 */
	@RequestMapping("/step1/step1Form.do")
	public String test1Form() {

		return "test1/test1Form";
	}
	
	/**
	 * <pre>
	 * @Date : 2019. 4. 22.
	 * @author dnms5
	 * @History : 
	 * @Description : 코딩테스트1 출력
	 * </pre>
	 *
	 * @return
	 */
	@RequestMapping("/step1/step1Result.do")
	public String test1Result() {
		
		return "test1/test1Result";
	}
}

package com.bluewaves.codingTest.jhProject.vo;

import java.sql.Date;

public class BoardVo {

	private int bNo;
	private String bTitle;
	private String bContent;
	private Date bDate;
	private String bName;
	private String bDel;
	
	public int getbNo() {
		return bNo;
	}
	public void setbNo(int bNo) {
		this.bNo = bNo;
	}
	public String getbTitle() {
		return bTitle;
	}
	public void setbTitle(String bTitle) {
		this.bTitle = bTitle;
	}
	public String getbContent() {
		return bContent;
	}
	public void setbContent(String bContent) {
		this.bContent = bContent;
	}
	public Date getbDate() {
		return bDate;
	}
	public void setbDate(Date bDate) {
		this.bDate = bDate;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public String getbDel() {
		return bDel;
	}
	public void setbDel(String bDel) {
		this.bDel = bDel;
	}
	
	
	
}

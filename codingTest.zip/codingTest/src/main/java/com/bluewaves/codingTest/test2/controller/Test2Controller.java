package com.bluewaves.codingTest.test2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <pre>
 * @FileName : Test2Controller.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트2 컨트롤러
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
@Controller
public class Test2Controller {

	/**
	 * <pre>
	 * @Date : 2019. 4. 22.
	 * @author dnms5
	 * @History : 
	 * @Description : 코딩테스트2 입력 폼
	 * </pre>
	 *
	 * @return
	 */
	@RequestMapping("/step2/step2Form.do")
	public String test2Form() {
		
		return "test2/test2Form";
	}
}

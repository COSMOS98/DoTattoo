package com.bluewaves.codingTest.jhProject.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.bluewaves.codingTest.jhProject.vo.BoardVo;
import com.bluewaves.codingTest.jhProject.vo.PagingDto;
import com.bluewaves.codingTest.jhProject.vo.UserVo;

public interface BoardMapper {
	
	public List<BoardVo> getBoardList(PagingDto pagingDto); //게시판 리스트
	public void insertContent(BoardVo boardVo); // 게시판 등록
	public BoardVo getContentByBno(String bNo); // 게시판 상세페이지 검색
	public void updateContent(BoardVo boardVo); // 게시판 수정
	public void deleteContent(BoardVo boardVo); // 게시판 삭제
	
	public void insertUser(UserVo userVo); // 사용자 등록
	public UserVo login(@Param("uId") String uId, @Param("uPw") String uPw);
	public int checkDupId(String uId);

}

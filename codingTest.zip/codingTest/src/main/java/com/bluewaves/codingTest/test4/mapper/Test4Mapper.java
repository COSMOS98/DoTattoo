package com.bluewaves.codingTest.test4.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.bluewaves.codingTest.test4.vo.Board4VO;
import com.bluewaves.codingTest.test4.vo.Paging4Dto;
import com.bluewaves.codingTest.test4.vo.Test4VO;

/**
 * <pre>
 * @FileName : Test4Mapper.java
 * @Date : 2019. 4. 22.
 * @author dnms5
 * @History : 
 * @Description : 코딩 테스트4 매퍼
 * </pre>
 *
 *
 * Copyright (C) 2019 by Bluewaves All right reserved.
 *
 */
public interface Test4Mapper {

	/**
	 * <pre>
	 * @Date : 2019. 4. 22.
	 * @author dnms5
	 * @History : 
	 * @Description : 코딩 테스트4 게시글 목록 조회
	 * </pre>
	 *
	 * @return
	 */
	public List<Test4VO> getList();
	public List<Board4VO> boardList(Paging4Dto paging4Dto);
	public int countList();
	public Board4VO getContent(Board4VO board4Vo);
	public void insertContent(Board4VO board4Vo);
	public void updateContent(Board4VO board4Vo);
	public void deleteContent(Board4VO board4Vo);
}
